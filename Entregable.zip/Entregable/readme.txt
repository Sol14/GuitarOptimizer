La imagen del PDF no esta funcionando muy bien, pues no tengo una foto mía
de las dimensiones necesarias.

El PDF debería funcionar en caso de que se quiera ver digital pero me ha pasado 
que en Windows no se pueda visualizar, por si acaso pasara puedo recompilarlo o llevar
una copia fisica
